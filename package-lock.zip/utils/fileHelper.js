import fs from 'fs';
export const getPosts = () => {
    return JSON.parse(fs.readFileSync('posts.json', 'utf-8'));

}

export const savePost = (posts) => {
    fs.writeFileSync('posts.json', JSON.stringify(posts, null, 3));

}
